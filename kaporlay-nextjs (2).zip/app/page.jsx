
"use client";
import React from "react";

const products = [
  {
    id: 1,
    name: "Classic Beige Shirt",
    price: "$39.99",
    image: "/shirt.jpg",
  },
  {
    id: 2,
    name: "Linen Casual",
    price: "$29.99",
    image: "/shirt.jpg",
  },
  {
    id: 3,
    name: "Formal Slim Fit",
    price: "$49.99",
    image: "/shirt.jpg",
  },
];

export default function Home() {
  return (
    <div className="bg-[#f9f5ef] min-h-screen font-serif">
      <div className="flex justify-between items-center px-8 py-5 bg-white shadow-sm border-b border-gray-200">
        <div className="text-3xl font-extrabold tracking-wide text-[#3d2b1f]">KAPORLAY</div>
        <div className="space-x-6 text-sm font-medium text-gray-700">
          <a href="#" className="hover:text-black transition">Home</a>
          <a href="#" className="hover:text-black transition">Shop</a>
          <a href="#" className="hover:text-black transition">About</a>
          <a href="#" className="hover:text-black transition">Contact</a>
          <button className="rounded-full border px-5 py-1">Login</button>
        </div>
      </div>

      <div className="relative h-[500px] bg-gradient-to-r from-[#f3e8dd] to-[#fdf8f3] flex items-center px-10 md:px-20">
        <div className="max-w-xl">
          <h1 className="text-6xl font-bold leading-tight text-[#3d2b1f] mb-4">Style That Speaks</h1>
          <p className="text-lg text-gray-600 mb-6">Timeless pieces for the modern wardrobe.</p>
          <button className="bg-[#3d2b1f] text-white px-8 py-3 rounded-full text-sm tracking-wide">Explore Collection</button>
        </div>
        <img
          src="/shirt.jpg"
          alt="Shirt Banner"
          className="h-96 object-contain hidden md:block ml-auto"
        />
      </div>

      <div className="py-20 px-6 bg-[#fffdf9]">
        <h2 className="text-4xl font-bold mb-10 text-center text-[#3d2b1f]">Featured Pieces</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10 max-w-7xl mx-auto">
          {products.map((product) => (
            <div key={product.id} className="rounded-3xl overflow-hidden shadow-md hover:shadow-xl transition">
              <img src={product.image} alt={product.name} className="w-full h-64 object-cover" />
              <div className="p-6">
                <h3 className="text-2xl font-semibold text-[#3d2b1f]">{product.name}</h3>
                <p className="text-gray-600 mt-1">{product.price}</p>
                <button className="mt-5 w-full rounded-full bg-[#3d2b1f] text-white py-2">Add to Cart</button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="text-center text-sm text-gray-500 py-6 border-t border-gray-200 bg-white">
        © 2025 <span className="font-semibold text-[#3d2b1f]">KAPORLAY</span>. Crafted with style.
      </div>
    </div>
  );
}
